*PADS-LIBRARY-PART-TYPES-V9*

AA2810ASES_J3 AA2810ASESJ3 I DIO 7 1 0 0 0
TIMESTAMP 2025.06.18.08.40.53
"Mouser Part Number" 604-AA2810ASES/J3
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Kingbright/AA2810ASES-J3?qs=jBF9H7RTBaSfc3RgDopyFA%3D%3D
"Manufacturer_Name" Kingbright
"Manufacturer_Part_Number" AA2810ASES/J3
"Description" Standard LEDs - SMD RA Red 625nm 1800mcd 110deg Water Clr
"Datasheet Link" http://www.kingbrightusa.com/images/catalog/SPEC/AA2810ASES-J3.pdf
"Geometry.Height" 0.9mm
GATE 1 2 0
AA2810ASES_J3
2 0 U K
1 0 U A

*END*
*REMARK* SamacSys ECAD Model
571543/1321111/2.50/2/3/LED
